###############################################################################
# Find all the 9.90 builds that includes the given P4 changelist.
###############################################################################

import os
import os.path
import sys


BASE_DIR = '//martin/archive/pv/TestCenter/9.90/Engineering_Builds/GUI_BLL'


def find_build(changelist):
    found = False
    dirs = os.listdir(BASE_DIR)
    for d in dirs:
        files = os.listdir(os.path.join(BASE_DIR, d))
        for f in files:
            if f.startswith('BLL_changelist'):
                # Extract the P4 changelist number
                n = os.path.splitext(f)
                idx = n[0].rindex('_')
                n = int(n[0][idx + 1:])
                if n > changelist:
                    print('Found in build ', os.path.join(BASE_DIR, d, f))
                    found = True
    return found

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('usage: python %s changelist_number' % sys.argv[0])
        sys.exit(1)
    changelist = int(sys.argv[1])
    found = find_build(changelist)
    if not found:
        print('Could not find changelist in any builds.')
