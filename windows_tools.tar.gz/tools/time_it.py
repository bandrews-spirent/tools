import os
import sys
import time

if len(sys.argv) != 2:
  print("Usage: %s <command>" % sys.argv[0])
  sys.exit(1)

cmd = sys.argv[1]

start_time = time.time()
os.system(cmd)
elapsed_time = time.time() - start_time
print("\n")
print("user time\t%s" % time.strftime("%Hh:%Mm:%Ss", time.gmtime(elapsed_time)))