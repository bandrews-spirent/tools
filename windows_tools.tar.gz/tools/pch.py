import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

def make_replacement(path):
    output = []
    with open(path, "r") as f:
        lines = f.readlines()
        header = ''
        replaced = False
        for l in lines:
            if l.find('StdAfx.h') != -1:
                start_idx = l.find("'")
                end_idx = l.rfind("'", start_idx + 1)
                header = l[start_idx+1:end_idx]
            if l.find("Utils.buildPCH") != -1 and header:
                replaced = True
                toks = l.split(")")
                newCode = "%s, '%s')\n" % (toks[0], header)
                output.append(newCode)
            else:
                output.append(l)


    if replaced:
        out = exec_cmd("p4 edit " + path)
        print out
        with open(path, "w") as f:
            for l in output:
                f.write(l)

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == "SConscript.bll"]
    for file in files:
        root = root.replace('mldSnooping', 'mldsnooping')
        path = os.path.join(root, file)
        make_replacement(path)
