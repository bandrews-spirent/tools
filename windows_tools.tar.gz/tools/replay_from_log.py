with open('client.bll.log', 'r') as f:
    lines = f.readlines()

with open('script.tcl', 'w') as f:
    for line in lines:
        if line.find('user.scripting') != -1:
            code = line.split('user.scripting       -')[1].strip()
            if code.find('stc::') != -1:
                f.write(code)
                f.write('\n')
