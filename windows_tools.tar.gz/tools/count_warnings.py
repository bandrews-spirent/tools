import os
import sys

if len(sys.argv) != 2:
  print("Usage: %s <filepath>" % sys.argv[0])
  sys.exit(1)

path = sys.argv[1]
counts = dict()

with open(path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            idx = line.find('[-W')
            if idx != -1:
                end = line.find(']', idx) + 1
                w = line[idx : end]
                counts[w] = counts.get(w, 0) + 1
                if line.find('.h:') != -1:
                    print(line)

for k, v in counts.items():
    print(k, v)
