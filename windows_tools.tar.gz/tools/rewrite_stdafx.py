import os
import subprocess


def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

def remove_duplicate_empty_lines(lines):
    output = []
    empty = False
    for l in lines:
        if not l.rstrip():
            if not empty:
                output.append(l)
            empty = True
        else:
            output.append(l)
            empty = False

    return output

def rewrite(path):
    output = []
    pragmas = []
    with open(path, "r") as f:
        lines = f.readlines()
        # Remove all #ifdef #endif to start fresh.
        for line in lines:
            if line.find("HAVE_ROUND") != -1:
                print "skipping", path
                return
            if line.find("#ifdef") == -1 and line.find("#endif") == -1 and \
                line.find("#define WIN32_LEAN_AND_MEAN") == -1 and \
                line.find("#include <winsock2.h>") == -1 and \
                line.find("#include <windows.h>") == -1:
                if line.find("#pragma") != -1:
                    pragmas.append(line)
                else:
                    output.append(line)


    # Add Windows stuff
    output.append("#ifdef WIN32\n")
    for p in pragmas:
        output.append(p)
    output.append("#define WIN32_LEAN_AND_MEAN\n")
    output.append("#include <winsock2.h>\n")
    output.append("#include <windows.h>\n")
    output.append("#endif\n\n")

    # Match include guard
    output.append("#endif\n\n")
    output = remove_duplicate_empty_lines(output)

    out = exec_cmd('p4 edit "%s"' % path)
    print out

    with open(path, "w") as f:
        for line in output:
            f.write(line)

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == "StdAfx.h"]
    for file in files:
        path = os.path.join(root, file)
        rewrite(path)
