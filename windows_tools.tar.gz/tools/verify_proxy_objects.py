import os
import os.path
import sys
import xml.etree.ElementTree

ns = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}
interface_dir = '../ui/BLLInterface/ProxyObjects/Generated'

e = xml.etree.ElementTree.parse('stcCore.processed.xml').getroot()
last_class_id = 0x1000000
for cls in e.findall('stc:class', ns):
    cls_id = cls.get('id')
    name = cls.get('name')
    cls_id_num = int(cls_id, 0)
    last_class_id = last_class_id + 0x00001000
    if last_class_id != cls_id_num:
        print("Class id %s is not sequential" % cls_id)
        break
    proxy_file = os.path.join(interface_dir, name + 'Proxy.Generated.cs')
    with open(proxy_file, 'r') as f:
        lines = f.readlines()
        found = False
        for line in lines:
            if line.find('ClassId = %s' % cls_id) != -1:
                found = True
                break;
        if not found:
            print('Could not find %s for class %s' % (cls_id, name))


