###############################################################################
## Finds all calls to CreateCommand in STAK .py files and checks to see if they have
## a MarkDelete.
###############################################################################

import os
import os.path
import sys

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f.endswith('.py') and 'test_' not in f]
    if 'bin\\Debug' not in root:
        for file in files:
            path = os.path.join(root, file)
            with open(path, 'r') as fh:
                lines = fh.readlines()
                count = 0
                for line in lines:
                    if 'CreateCommand(' in line:
                        count = count + 1
                mark_delete = 0
                if count > 0:
                    for line in lines:
                        if 'MarkDelete' in line:
                            mark_delete = mark_delete + 1
                if mark_delete < count:
                    print path, ", CreateCommand count: ", count, ", MarkDelete count: ", mark_delete



