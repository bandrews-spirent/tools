# missing timepoint 4 and 7
port0_rx_rates = [(1, 100), (2, 100), (3, 200), (5, 200), (6, 200)]

# missing timepoint 2
port1_rx_rates = [(1, 100), (3, 200), (4, 200), (5, 200), (6, 200), (7, 200)]

# get all timepoints from all sets of data
timepoints = set()
for r in port0_rx_rates:
    timepoints.add(r[0])

for r in port1_rx_rates:
    timepoints.add(r[0])

def normalize(rates):
    rates_normalized = []
    idx = 0
    last_val = ()
    for t in timepoints:
        if idx >= len(rates):
            # use last value with new timepoint
            rates_normalized.append((t, last_val[1]))
        elif rates[idx][0] == t:
            last_val = rates[idx]
            rates_normalized.append(last_val)
            idx = idx + 1
        else:
            # use last value with new timepoint
            rates_normalized.append((t, last_val[1]))
    return rates_normalized

# normalize data sets
port0_rates_normalized = normalize(port0_rx_rates)
port1_rates_normalized = normalize(port1_rx_rates)
assert len(port0_rates_normalized) == len(port1_rates_normalized)

# calculate sums
rate_sums = []
for i in range(0, len(port0_rates_normalized)):
    timepoint = port0_rates_normalized[i][0]
    total = port0_rates_normalized[i][1] + port1_rates_normalized[i][1]
    rate_sums.append((timepoint, total))

print rate_sums
