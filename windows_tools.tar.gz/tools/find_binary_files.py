import os
import sys

def is_binary(path, size_threshold_mb):
    with open(path, 'rb') as f:
        data = f.read(512)
        size = os.path.getsize(path) / 1024 / 1024
        return size >= size_threshold_mb and b'\0' in data


for fd, subfds, fns in os.walk('.'):
    for f in fns:
        path = os.path.join(fd, f)
        if 'bin\\Debug' not in fd and 'bin\\Release' not in fd and \
            'common\\tools' not in fd and \
            'common\\lib' not in fd and \
                not path.endswith('.cpp') and \
                not path.endswith('.h') and \
                not path.endswith('.txt') and \
                not path.endswith('.xml') and \
                not path.endswith('.py') and \
                not path.endswith('.pyc') and \
                not path.endswith('.obj') and \
                not path.endswith('.pch') and \
                not path.endswith('.pdb') and \
                not path.endswith('.resources') and \
                not path.endswith('.cache') and \
                not path.endswith('.res') and \
                not path.endswith('sconsign.dblite') and \
                not path.endswith('.ipch') and \
                not path.endswith('RCM.db') and \
                is_binary(path, 10):
            size = os.path.getsize(path) / 1024 / 1024
            print(path, size, 'MB')

