import copy
import os
import re
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines


def make_replacement(path):
    LIST_OF_TAG_1 = 'boost::assign::list_of'
    LIST_OF_TAG_2 = 'list_of'
    MAP_LIST_OF_TAG_1 = 'boost::assign::map_list_of'
    MAP_LIST_OF_TAG_2 = 'map_list_of'

    output = []
    replaced = False
    with open(path, 'r') as f:
        # print(path)
        try:
            lines = f.readlines()
            inside_list_of = False
            inside_map_list_of = False
            list_of_tag_1 = False
            list_of_tag_2 = False
            map_list_of_tag_1 = False
            map_list_of_tag_2 = False

            for l in lines:
                if l.find('#include') != -1 and l.find('boost/assign') != -1:

                    # Scan for tuple_list_of before removing #include
                    tuple_lines = [l for l in lines if l.find('tuple_list_of') != -1]
                    if not tuple_lines:
                        replaced=True
                        continue
                if l.find('using namespace boost::assign') != -1:
                    replaced=True
                    continue

                # Skip tuples for now. boost::tuple needs to be replaced as well.
                if l.find('tuple_list_of') != -1:
                    output.append(l)
                    continue

                start_idx = l.find(MAP_LIST_OF_TAG_2)
                if start_idx != -1 or inside_map_list_of:
                    replaced = True
                    if start_idx != -1:
                        map_list_of_tag_1 = l.find(MAP_LIST_OF_TAG_1) != -1
                        map_list_of_tag_2 = l.find(MAP_LIST_OF_TAG_2) != -1

                    new_code = l.replace(MAP_LIST_OF_TAG_1, '{')
                    new_code = new_code.replace(MAP_LIST_OF_TAG_2, '{')

                    new_code = re.sub('\.convert_to_container<.*?>.*?\(.*?\)', '', new_code)

                    # Replace only the first paren.
                    new_code = re.sub(r'\(', '{', new_code, 1)
                    # Replace closing paren, but not inner ones.
                    new_code = re.sub(r'\)(?=[^\(\)]*$)', '},', new_code)

                    if inside_map_list_of:
                        # Tabs to spaces
                        new_code = new_code.replace('\t', ' ' * 4)

                        # Align code to the removed boost function call.
                        count = len(MAP_LIST_OF_TAG_1) if map_list_of_tag_1 else len(MAP_LIST_OF_TAG_2)
                        if new_code.startswith(' ' * count):
                            new_code = new_code[count - 1:]

                    inside_map_list_of = l.find(';') == -1

                    # Replace last comma
                    if not inside_map_list_of:
                        new_code = re.sub(r',\s*(?=[^,]*$)', '}', new_code)
                        map_list_of_tag_1 = False
                        map_list_of_tag_2 = False
                    output.append(new_code)
                    continue

                start_idx = l.find(LIST_OF_TAG_2)
                if start_idx != -1 or inside_list_of:
                    replaced = True
                    if start_idx != -1:
                        list_of_tag_1 = l.find(LIST_OF_TAG_1) != -1
                        list_of_tag_2 = l.find(LIST_OF_TAG_2) != -1

                    new_code = l.replace(LIST_OF_TAG_1, '')
                    new_code = new_code.replace(LIST_OF_TAG_2, '')

                    new_code = re.sub('\)\s*\(', ', ', new_code)
                    new_code = re.sub('\.convert_to_container<.*?>.*?\(.*?\)', '', new_code)

                    # Replace only the first paren.
                    new_code = re.sub(r'\(', '{', new_code, 1)
                    # Replace closing paren, but not inner ones.
                    new_code = re.sub(r'\)(?=[^\(\)]*$)', ',', new_code)

                    if inside_list_of:
                        new_code = re.sub(r'\{', '', new_code, 1)

                        # Tabs to spaces
                        new_code = new_code.replace('\t', ' ' * 4)

                        # Align code to the removed boost function call.
                        count = len(LIST_OF_TAG_1) if list_of_tag_1 else len(LIST_OF_TAG_2)
                        if new_code.startswith(' ' * count):
                            new_code = new_code[count - 1:]

                    inside_list_of = l.find(';') == -1
                    # Replace last comma, close with bracket.
                    if not inside_list_of:
                         new_code = re.sub(r',([^,]*)$', r'}\1', new_code)
                         list_of_tag_1 = False
                         list_of_tag_2 = False
                    output.append(new_code)
                else:
                    output.append(l)
        except UnicodeDecodeError:
            print(path, '---> was skipped due to decoding error')

    if replaced:
       print(path)
       out = exec_cmd('p4 edit "%s"' % path)
       print(out)
       with open(path, 'w') as f:
          for l in output:
              f.write(l)

for root, dirs, files, in os.walk('.'):
    files = [f for f in files if f.endswith('.cpp') or f.endswith('.h')]
    for file in files:
        path = os.path.join(root, file)
        if path.find('lib\\utest') != -1:
            print('skipping', path)
            continue
        make_replacement(path)
