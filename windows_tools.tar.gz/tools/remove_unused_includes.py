import copy
import os
import re
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

BOOST_LIBS = ['shared_ptr', 'weak_ptr', 'assign', 'tuple', 'bind', 'regex', 'mutex', 'multi_index', 'bimap']

def make_replacement(path):
    output = []
    replaced = False
    with open(path, 'r') as f:
        # print(path)
        try:
            lines = f.readlines()

            for l in lines:
                if l.find('#include') != -1 and l.find('boost') != -1:
                    lib = None
                    for bl in BOOST_LIBS:
                        if l.find(bl) != -1:
                            lib = bl
                            break
                    if lib is not None:
                        # Scan all lines for any usage
                        usage_lines = [l for l in lines if l.find('boost') != -1 and l.find(lib) != -1 and l.find('#include') == -1]
                        if not usage_lines:
                            print('usage not found', lib, 'in', path)
                            replaced = True
                            continue
                output.append(l)
        except UnicodeDecodeError:
            print(path, '---> was skipped due to decoding error')

    if replaced:
       print(path)
       out = exec_cmd('p4 edit "%s"' % path)
       print(out)
       with open(path, 'w') as f:
          for l in output:
              f.write(l)

for root, dirs, files, in os.walk('.'):
    files = [f for f in files if (f.endswith('.cpp') or f.endswith('.h')) and f.find('StdAfx') == -1]
    for file in files:
        path = os.path.join(root, file)
        if path.find('lib\\utest') != -1:
            print('skipping', path)
            continue
        make_replacement(path)
