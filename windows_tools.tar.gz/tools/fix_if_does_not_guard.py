import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

could_not_fix = []

def fix(path, line_num):
    with open(path, 'r') as f:
        lines = f.readlines()
    line = lines[line_num]
    if not line.strip() or line.strip().startswith('if ') or line.strip().startswith('if('):
        could_not_fix.append((file, line_num, line))
    else:
        print('Fixing %s %s' % (file, line_num))
        print(lines[line_num])
        out = exec_cmd('p4 edit "%s"' % file)
        print(out)
        space_count = len(line) - len(line.lstrip(' '))
        lines.insert(line_num, ' ' * space_count + '{')
        lines.insert(line_num + 1, line)
        lines.insert(line_num + 2, ' ' * space_count + '}')
        with open(path, 'w') as f:
            for line in lines:
                f.write(line)

with open('compile-log.txt', 'r') as f:
    lines = f.readlines()
    for line in lines:
        if line.find('[-Wmisleading-indentation]') != -1:
            tokens = line.split(' warning:')
            tokens = tokens[0].split(':')
            file = tokens[0]
            line_num = tokens[1]
            fix(file, int(line_num))

if could_not_fix:
    print("Could not fix.")
    for line in could_not_fix:
        print(could_not_fix)
