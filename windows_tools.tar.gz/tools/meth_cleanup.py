import os
import os.path
import sys
import xml.etree.ElementTree

ns = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}

all_meth_files = [
    #'stc_methodology_api.xml',
    'stc_methodologymanager.xml',
    'stc_methodology_portsetup.xml',
    'stc_methodology_routing.xml',
    'stc_methodology_sampling.xml',
    'stc_methodology_stm_objects.xml',
    'stc_methodology_traffic.xml',
    'stc_testmethodology.xml'
    ]

def internal_used_by_public(internal_classes, public_classes):
    '''
    Check to see if any internal classes (which are candidates for delete)
    are used by any of the public classes.
    '''
    ok_for_delete = internal_classes
    # for fd, subfds, fns in os.walk('.'):
    #     for f in fns:
    #         tokens = os.path.splitext(f)
    #         if len(tokens) == 2 and tokens[0] in public_classes:
    #             path = os.path.join(fd, f)
    #             with open(path, 'r') as fh:
    #                 lines = fh.read()
    #                 for cls in internal_classes:
    #                     if cls in lines:
    #                         print(cls, 'is used by', path, 'therefore cannot be deleted')
    #                         ok_for_delete.remove(cls)
    #                         break

    for fd, subfds, fns in os.walk('.'):
        for f in fns:
            if f.endswith('.py') and not f.startswith('test_'):
                path = os.path.join(fd, f)
                with open(path, 'r') as fh:
                    lines = fh.read()
                    for cls in internal_classes:
                        if f == 'unit_test_utils.py' and cls == 'ExportSequencerCommand':
                            print('here!!!!', cls, ':')
                            idx = lines.find(cls)
                            print('idx', idx)
                        if lines.find(cls) != -1 and f.find(cls) == -1:
                            print(cls, 'is used by', path, 'therefore cannot be deleted')
                            ok_for_delete.remove(cls)

    # Mark for delete
    tests_to_delete = []
    for fd, subfds, fns in os.walk('.'):
        for f in fns:
            tokens = os.path.splitext(f)
            if f.endswith('.py') and len(tokens) == 2 and tokens[0] in ok_for_delete:
                path = os.path.join(fd, f)
                tests_to_delete.append('test_' + os.path.basename(f))
                print(path, 'is OK for delete')
                #os.system('p4 delete {}'.format(path))

    # Mark test files for delete.
    for fd, subfds, fns in os.walk('.'):
        for f in fns:
            if f.endswith('.py') and f in tests_to_delete:
                path = os.path.join(fd, f)
                print(path, 'is OK for delete')
                #os.system('p4 delete {}'.format(path))

def load_all_public_classes():
    public_classes = []
    for f in all_meth_files:
        e = xml.etree.ElementTree.parse(f).getroot()
        for cls in e.findall('stc:class', ns):
            name = cls.get('name')
            internal = cls.get('isInternal')
            if not internal or internal == 'false':
                public_classes.append(name)
    return public_classes


def scan_classes(file):
    public_classes = []
    internal_classes = []
    e = xml.etree.ElementTree.parse(file).getroot()
    for cls in e.findall('stc:class', ns):
        name = cls.get('name')
        internal = cls.get('isInternal')
        if internal and internal == 'true':
            internal_classes.append(name)
        else:
            public_classes.append(name)

    print('public classes', len(public_classes))
    print(public_classes)

    print('internal classes', len(internal_classes))
    print(internal_classes)

    all_public_classes = load_all_public_classes()
    print('all public classes total', len(all_public_classes))
    internal_used_by_public(internal_classes, all_public_classes)

# The STAK command metadata we're interested in.
file = sys.argv[1]
scan_classes(file)