import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

def namespace_from_include(include):
    i = include.split(' ')[1]
    i = i.replace('.hpp', '').replace('/', '::').replace('"', '').replace("<", '').replace(">", '').rstrip(os.linesep)
    i = i.replace("boost::foreach", "BOOST_FOREACH")
    return i


def change_cpp(path, includes):
    includes_needed = []
    with open(path, "r") as f:
        lines = f.read()
        for i in includes:
            nm = namespace_from_include(i)
            bracket_include = i.replace('"', '<', 1)
            bracket_include = bracket_include.replace('"', '>', 1)
            if lines.find(nm) != -1 and lines.find(i) == -1 and lines.find(bracket_include) == -1:
                includes_needed.append(i)
    if includes_needed:
        print path, "needs", includes_needed
        out = exec_cmd('p4 edit "%s"' % path)
        print out
        outlines = []
        with open(path, "r") as f:
            lines = f.readlines()
            # Find first boost include and stick it the needed includes there.
            done = False
            for l in lines:
                if not done and (l.find("include") != -1 and l.find("boost") != -1):
                    done = True
                    for i in includes_needed:
                        outlines.append(i)
                outlines.append(l)

            # If no existing boost include, just stick them after the StdAfx.h
            if not done:
                outlines = []
                for l in lines:
                    if not done and l.find("StdAfx.h") != -1:
                        done = True
                        outlines.append(l)
                        for i in includes_needed:
                            outlines.append(i)
                    else:
                        outlines.append(l)

            # If no StdAfx.h, just put them at the first blank line
            if not done:
                outlines = []
                for l in lines:
                    if not done and not l.rstrip(os.linesep).strip():
                        done = True
                        outlines.append(l)
                        for i in includes_needed:
                            outlines.append(i)
                    else:
                        outlines.append(l)


        with open(path, "w") as f:
            for line in outlines:
                f.write(line)


def change_boost(path):
    out = exec_cmd('p4 edit "%s"' % path)
    print out
    outlines = []
    boost_start = False
    has_win32 = False
    includes = []
    with open(path, "r") as f:
        lines = f.readlines()
        for line in lines:
            if line.find("#ifdef WIN32") != -1:
                has_win32 = True
                #line = line.replace("#ifdef WIN32", "#ifdef _MSC_VER")
            if line.find("boost") != -1 and not has_win32:
                if not boost_start:
                    boost_start = True
                    has_win32 = False
                    outlines.append("#ifdef WIN32\n")
                includes.append(line)
            elif not line.rstrip(os.linesep).strip() and boost_start:
                boost_start = False
                outlines.append("#endif\n")
            outlines.append(line)

    with open(path, "w") as f:
        for line in outlines:
            f.write(line)

    if includes:
        src_path = os.path.abspath(os.path.join(os.path.dirname(path), "../../"))
        for root, dirs, files, in os.walk(src_path):
            files = [f for f in files if (f.endswith(".cpp") or f.endswith(".h")) and (f.find("_AutoGen.cpp") == -1 and f.find("StdAfx.h") == -1)]
            for file in files:
                path = os.path.join(root, file)
                change_cpp(path, includes)


for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == "StdAfx.h"]
    for file in files:
        path = os.path.join(root, file)
        change_boost(path)
