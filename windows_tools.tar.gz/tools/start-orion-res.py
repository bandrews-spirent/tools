import requests
import socket
import subprocess
import sys
import time

cmd = 'orion-res.exe -c ..\etc\orion-res.yaml'

count = 0
while True:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(('localhost', 9005))
    except socket.error:
        print 'Could not bind socket'
        sys.exit(1)

    s.close()

    p = subprocess.Popen(cmd)
    if p.poll() is not None:
        print 'failed'
        sys.exit(1)

    url = 'http://localhost:9005/version'
    response = requests.get(url)
    if response.status_code != 200:
        print 'failed ', response.status_code
        sys.exit(1)
    else:
        try:
            #print response.json()
            json = response.json()
            if 'build_number' not in json:
                print 'invalid response', json
                sys.exit(1)
        except:
            print 'expecting JSON response'
            sys.exit(1)

    p.kill()
    if count % 100 == 0:
        print 'iteration', count, 'complete'
    count = count + 1
