import os
import sys
import time
from threading import Thread

class ProcessRunner(Thread):
    def __init__(self, cmd):
        Thread.__init__(self)
        self.cmd = cmd

    def run(self):
        os.system(self.cmd)

if len(sys.argv) != 4:
    print("Usage: %s <command> <loop_count> <threads>" % sys.argv[0])
    sys.exit(1)

cmd = sys.argv[1]
count = int(sys.argv[2])
threads = int(sys.argv[3])

for i in range(0, count):
    runners = []
    for j in range(0, threads):
        runner = ProcessRunner(cmd)
        runners.append(runner)
        runner.start()

    for r in runners:
        r.join()

    print("iteration %d complete" % (i+1))

