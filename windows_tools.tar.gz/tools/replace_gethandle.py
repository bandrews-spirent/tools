import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines


def make_replacement(path):
    output = []
    replaced = False
    with open(path, 'r') as f:
        try:
            lines = f.readlines()
            for l in lines:
                if l.find('.GetHandle(') != -1:
                    replaced = True
                    new_code = l.replace('.GetHandle', '.GetObjectHandle')
                    #print(l, new_code)
                    output.append(new_code)
                else:
                    output.append(l)
        except UnicodeDecodeError:
            print(path, '---> was skipped due to decoding error')


    if replaced:
        print(path)
        out = exec_cmd('p4 edit ' + path)
        print(out)
        with open(path, 'w') as f:
           for l in output:
               f.write(l)

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f.endswith('.cpp') or f.endswith('.h')]
    for file in files:
        path = os.path.join(root, file)
        make_replacement(path)
