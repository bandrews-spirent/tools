import os
import re


def make_replacement(path):
    with open(path, "r") as f:
        data = f.read()
        data = re.sub(r'/D\s+"([^"]+)"', r'/D\1', data)
    with open(path, "w") as f:
        f.write(data)

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == "SConscript.bll"]
    for file in files:
        path = os.path.join(root, file)
        make_replacement(path)
