import os
import os.path
import sys
import xml.etree.ElementTree

ns = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}

path = os.getcwd()

xml_files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f)) and f.startswith('stc') and f.endswith('.xml')]

for f in xml_files:
    e = xml.etree.ElementTree.parse(os.path.join(path, f)).getroot()
    for cls in e.findall('stc:class', ns):
        d = cls.get('isDeprecated', '')
        if d:
            print(cls)