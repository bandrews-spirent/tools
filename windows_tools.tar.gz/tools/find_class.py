###############################################################################
## Finds a class by class id in the STC model directory.
###############################################################################

import os
import os.path
import sys
import xml.etree.ElementTree

if len(sys.argv) != 3:
    print('Usage: %s <path to model folder> <integer class id>' % sys.argv[0])
    sys.exit(1)

path = sys.argv[1]
class_id = int(sys.argv[2])

xml_files = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f)) and f.endswith('processed.xml')]
if not xml_files:
    print('%s is not a valid model folder' % path)
    sys.exit(1)

ns = {'stc': 'urn:www.spirentcom.com:XMLSchema.xsd'}

found = False
for f in xml_files:
    e = xml.etree.ElementTree.parse(os.path.join(path, f)).getroot()
    for cls in e.findall('stc:class', ns):
        cls_id = int(cls.get('id'), 0)
        if cls_id == class_id:
            print('Found %s' % cls.get('name'))
            found = True
            break
    if found:
        break

if not found:
    print('Not found')
    sys.exit(1)
