import os
import shutil

BUILD_DIR          = 'C:/Users/titan/src/bin/Debug'
ORION_RES_FILE     = 'orion-res.windows-386.zip'
FRONTEND_FILE      = 'magellan-frontend.tar'
ORION_RES_DIR      = BUILD_DIR + '/orion-res'
DUT_COLLECTOR_DIR  = BUILD_DIR + '/dut-collector'
DUT_COLLECTOR_FILE = 'dut-collector.windows-386.tgz'
IQ_DATA_DIR        = BUILD_DIR + '/iq-data'
IQ_DATA_FILE       = 'iq-data.windows-386.tgz'

f = os.path.join(BUILD_DIR, ORION_RES_FILE)
if os.path.exists(f):
    os.remove(f)

f = os.path.join(BUILD_DIR, IQ_DATA_FILE)
if os.path.exists(f):
    os.remove(f)

f = os.path.join(BUILD_DIR, DUT_COLLECTOR_FILE)
if os.path.exists(f):
    os.remove(f)

if os.path.exists(ORION_RES_DIR):
    shutil.rmtree(ORION_RES_DIR, ignore_errors=True)

if os.path.exists(DUT_COLLECTOR_DIR):
    shutil.rmtree(DUT_COLLECTOR_DIR, ignore_errors=True)

if os.path.exists(IQ_DATA_DIR):
    shutil.rmtree(IQ_DATA_DIR, ignore_errors=True)

# Get latest orion-res
os.system('wget https://artifactory.srv.orionprod.net/artifactory/stc/temeva/orion-res.windows-386.zip')
os.system('wget https://artifactory.srv.orionprod.net/artifactory/stc/temeva/magellan-frontend.tgz')
#os.system('wget https://artifactory.srv.orionprod.net/artifactory/stc/temeva/magellan-frontend-commit/1327/magellan-frontend.tgz')
os.system('unzip %s -d %s' % (ORION_RES_FILE, ORION_RES_DIR))
os.remove(ORION_RES_FILE)
os.system('gzip -d magellan-frontend.tgz')
shutil.move(FRONTEND_FILE, ORION_RES_DIR)
current_dir = os.getcwd()
os.chdir(ORION_RES_DIR)
os.system('tar -xvf %s' % FRONTEND_FILE);
shutil.move('build', 'content')
os.remove(FRONTEND_FILE)
os.chdir(current_dir)
os.system('chmod -R 755 %s' % ORION_RES_DIR)

# Get latest iq-data
os.system('wget https://artifactory.srv.orionprod.net/artifactory/stc/temeva/iq-data-commit/iq-data.windows-386.tgz')
shutil.move(IQ_DATA_FILE, BUILD_DIR)
os.chdir(BUILD_DIR)
os.system('tar -xvf %s' % IQ_DATA_FILE);
os.remove(IQ_DATA_FILE)
os.chdir(current_dir)
os.system('chmod -R 755 %s' % IQ_DATA_DIR)

# Get latest dut-collector
os.system('wget https://artifactory.srv.orionprod.net/artifactory/stc/temeva/dut-collector-commit/dut-collector.windows-386.tgz')
shutil.move(DUT_COLLECTOR_FILE, BUILD_DIR)
os.chdir(BUILD_DIR)
os.system('tar -xvf %s' % DUT_COLLECTOR_FILE);
os.remove(DUT_COLLECTOR_FILE)
os.chdir(current_dir)
os.system('chmod -R 755 %s' % DUT_COLLECTOR_DIR)
