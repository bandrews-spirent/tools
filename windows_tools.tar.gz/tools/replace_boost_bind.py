import copy
import os
import re
import subprocess
import sys

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines


def make_replacement(path):
    output = []
    replaced = False
    with open(path, 'r') as f:
        # print(path)
        try:
            lines = f.readlines()

            for l in lines:
                #if l.find('#include') != -1 and l.find('boost/bind') != -1:
                #    replaced=True
                #    continue

                # Leave it be if it has an operator. Needs to be converted to lambda
                if '==' in l or '!=' in l or '<=' in l or '>=' in l:
                    output.append(l)
                    continue

                start_idx = l.find('boost::bind')
                if start_idx != -1:
                    replaced = True
                    pattern = r'boost::bind\(([^)]*)\)'
                    new_code = re.sub(pattern, r'\1', l)
                    new_code = new_code.replace('&', '')
                    new_code = new_code.replace(', _1', '')
                    new_code = new_code.replace(', _2', '')
                    new_code = new_code.replace(', _3', '')
                    output.append(new_code)
                else:
                    output.append(l)
        except UnicodeDecodeError:
            print(path, '---> was skipped due to decoding error')

    if replaced:
       print(path)
       out = exec_cmd('p4 edit "%s"' % path)
       print(out)
       with open(path, 'w') as f:
          for l in output:
              f.write(l)

path = sys.argv[1]
make_replacement(path)

