import re

classid = 1
interface_dir = '../ui/BLLInterface/ProxyObjects/Generated'
regex = re.compile('<stc:class classId="[\\d]+"')

with open('stcCore.out.xml', 'w') as outfile:
    with open('stcCore.xml', 'r') as infile:
        for line in infile:
            if line.find('<stc:class classId') != -1:
                line = re.sub(regex, '<stc:class classId="%s"' % classid, line)
                classid = classid + 1
            outfile.write(line)
