import os

def upgrade_dot_net():
    for root, dirs, files, in os.walk("."):
        files = [f for f in files if f.endswith('.csproj')]
        for file in files:
            path = os.path.join(root, file)
            os.system(f"p4 edit {path}")
            new_lines = []
            with open(path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    line = line.replace('<TargetFrameworkVersion>v4.6.1</TargetFrameworkVersion>', '<TargetFrameworkVersion>v4.7.2</TargetFrameworkVersion>')
                    new_lines.append(line)
            with open(path, 'w') as f:
                for line in new_lines:
                    f.write(line)

def _remove_mfc(my_path):
    for root, dirs, files, in os.walk(my_path):
        files = [f for f in files if f.endswith('.rc')]
        for file in files:
            path = os.path.join(root, file)
            if path.find('dummy_for') != -1:
                continue
            os.system(f"p4 edit {path}")
            new_lines = []
            with open(path, 'r') as f:
                lines = f.readlines()
                for line in lines:
                    line = line.replace('afxres.h', 'winres.h')
                    new_lines.append(line)
            with open(path, 'w') as f:
                for line in new_lines:
                    f.write(line)

def remove_mfc():
    _remove_mfc('framework')
    _remove_mfc('content')


# upgrade_dot_net()
remove_mfc()
