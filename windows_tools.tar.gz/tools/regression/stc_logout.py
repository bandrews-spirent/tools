import os
stc_dir = os.environ['STC_BUILD_DIR']
print('STC_BUILD_DIR', stc_dir)
os.environ['STC_PRIVATE_INSTALL_DIR'] = stc_dir

from StcPython import StcPython
stc = StcPython()
stc.perform('TemevaSignOut')

