import os
import sys

def walk_dir(d):
    files = []
    for fd, subfds, fns in os.walk(d):
        for f in fns:
            path = os.path.join(fd, f)
            path = path[len(d)+1:]
            #print(path)
            files.append(path)
    return files


old_dir = sys.argv[1]
new_dir = sys.argv[2]

print('Getting files from', old_dir)
old_dir_files = walk_dir(old_dir)
print('number of files -->', len(old_dir_files))

print('Getting files from', new_dir)
new_dir_files = walk_dir(new_dir)
print('number of files -->', len(new_dir_files))

for f in old_dir_files:
    if f not in new_dir_files:
        print('new dir is missing -->', f)

for f in new_dir_files:
    if f not in old_dir_files:
        print('old dir does not have -->', f)
