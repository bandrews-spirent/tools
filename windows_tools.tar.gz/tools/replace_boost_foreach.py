import copy
import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines


def make_replacement(path):
    output = []
    replaced = False
    with open(path, 'r') as f:
        # print(path)
        try:
            lines = f.readlines()
            for l in lines:
                if l.find('#include') != -1 and l.find('boost/foreach.hpp') != -1:
                    replaced=True
                    continue
                start_idx = l.find('BOOST_FOREACH')
                if start_idx != -1 and l.find('//') == -1:
                    replaced = True
                    end_idx = l.find(',', start_idx) + 1
                    original_code = l[start_idx : end_idx]
                    normalized_code = original_code.replace('*', '')
                    is_ref = normalized_code.find('&') != -1
                    is_string = normalized_code.find('string') != -1
                    tokens = normalized_code.split(' ')
                    tokens = [t for t in tokens if t != '' and t != ',']
                    var_type = tokens[len(tokens) -2]
                    var_idx = var_type.find('(')
                    if var_idx != -1:
                        var_type = var_type[var_idx + 1 : len(var_type)]
                    var_name = tokens[len(tokens) -1]

                    # Normalize ref and pointer types.
                    new_var_name = var_name.replace('&', '')
                    new_var_name = new_var_name.replace('*', '')

                    new_code = copy.copy(normalized_code)

                    # If it was a ref, make it a ref.
                    # If it was a std::string, make it a ref, even if it was not a ref before.
                    if is_ref or is_string:
                        new_code = new_code.replace(var_type, 'auto&')
                    else:
                        new_code = new_code.replace(var_type, 'auto')

                    new_code = new_code.replace(var_name, new_var_name)
                    new_code = new_code.replace(',', ' :')
                    new_code = new_code.replace('BOOST_FOREACH', 'for')

                    # misc 2 word type
                    new_code = new_code.replace('unsigned', '')

                    # tidy up. Make it look like a good programmer did it. :)
                    new_code = new_code.replace('for(', 'for (')
                    new_code = new_code.replace('  :', ' :')
                    new_code = new_code.replace(':  ', ': ')
                    new_code = new_code.replace('auto  ', 'auto ')


                    # Make std::string const. This way compiler
                    # will catch any problems with making std::string a ref.
                    #if is_string and new_code.find('const ') == -1:
                    #    new_code = new_code.replace('auto', 'const auto')

                    #print(normalized_code, new_code)
                    new_code = l.replace(original_code, new_code)
                    output.append(new_code)
                else:
                    output.append(l)
        except UnicodeDecodeError:
            print(path, '---> was skipped due to decoding error')

    if replaced:
       print(path)
       out = exec_cmd('p4 edit "%s"' % path)
       print(out)
       with open(path, 'w') as f:
          for l in output:
              f.write(l)

for root, dirs, files, in os.walk('.'):
    files = [f for f in files if f.endswith('.cpp') or f.endswith('.h')]
    for file in files:
        path = os.path.join(root, file)
        make_replacement(path)
