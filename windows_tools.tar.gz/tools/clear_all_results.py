import requests
import time

BASE_URI = 'http://localhost:9700'

while True:
    r = requests.post(BASE_URI + '/perform?command=ResultsClearAll')
    print(r.status_code)
    print(r.json())
    time.sleep(10)
