#!/bin/bash
#
# author: Derek Ealy - derek.ealy@spirent.com
# 6/7/24

# Setup TestCenter environment on Windows

os=$(uname)
repo="git@github.com:Spirent-STC/testcenter.git"
dev_env="all"
test_run=0
depth=1
depth_arg="--depth=$depth"

clone_dir=""
branch_name="integration"

win_pat="'/*' '!il/' '!userdocauto' '!WebHelp/' \
         'build/il' '!build/il/cli' '!build/il/testframework' '!common/lib/ACE_wrappers_5.4.0' \
         '!common/lib/ACE_wrappers_5.5.6' '!scm' '!content/traffic/ttwb' '!common/lib/boost_1_64_0' '!common/lib/eXtremeDB'"
il_dev_pat="'/*' '!userdocauto' '!scm' '!content/**/bll' '!framework/ui'"
il_build_pat="'/*' '!sandbox/' '!WebHelp/' '!documents/' '!schedules/' '!scm/' '!regression/' '!userdocauto/' '!framework/ui/' '!content/**/ui/'"
stak_pat="'framework/bll/pl/bll/install/common/STAKCommands/*'"
userdocauto_pat="'userdocauto/*'"
tech_pubs_pat="'framework/ui/automation/HelpInfo/*' 'userdocauto/*' 'scm/installer/Files/Spirent TestCenter Documentation/*'"
all_pat="/*"
dir_patterns=""

helptxt="\n\nClone the testcenter environment with options for a sparse checkout. This script will do
         some basic environment checks to ensure the needed configs and software are available for
         interacting with Git and Artifactory.\n\n

         With the -p option an external file with .gitignore style patterns can be specified to have
         custom directories included and excluded in the sparse checkout.\n\n

         This bash script can run in Git Bash on Windows, however on some systems there appears to be a
         conflict between the Git Bash version of ssh-agent and the one that is installed by default
         OpenSSH. If this script does work in your environment then you can keep using it, however
         if you are unable to do the sparse-checkout without repeated requests for your password
         then you will probably be better served by the Powershell version of this script
         tc-clone.ps1.
         \n\n"
usage() {
    echo -e "Usage: $0 [-h] [-e] [clone-dir]"
    echo ""
    echo -e "  -h Display help message"
    echo -e "  -c Check environment"
    echo -e "  -d Inital clone depth (default = 1)"
    echo -e "  -r Git repo SSH addr e.g. git@github.com:Spirent-STC/testcenter.git"
    echo -e "  -t Test run, don't clone or checkout anything"
    echo -e "  -p Sparse directory pattern file"
    echo -e "  -e dev_env  - win | il-d (dev) | il-b (build node) | stak (STAKCommands) | userdocauto | techpubs | all (default) clones dirs for windows, IL or everything in repo"
    echo -e "  -b single_branch_name"
    echo -e "  -x Enable trace logging"
    echo -e "  clone-dir(optional)  - directory to clone into"
    echo -e ${helptxt} 1>&2; exit 1;
}

# 1. Verify Git and git lfs, SSH and private/public key are available
check-env() {
    git lfs version
    if [[ "$?" != "0" ]]; then
        echo -e "Git and or git-lfs are not installed on this system. Please install Git and git-lfs"
        if [[ "$os" == "Linux" ]]; then
            echo -e "Use your package manager (yum, dnf, apt) to install git."
        elif [[ "$os" == "Darwin" ]]; then
            echo -e "Use your package manager to install git or download from git-scm.comg."
        else
            echo -e "On Windows don't install Git 2.45 there is a bug that will interfere, use 2.41, below is a link to the installer."
            echo -e "https://spirent1.sharepoint.com/sites/cip/Core/FirmwareInfrastructure/Shared%20Documents/Git/Git-2.41.0.3-64-bit.exe"
        fi

        echo -e "Install git-lfs from here: https://docs.github.com/en/repositories/working-with-files/managing-large-files/installing-git-large-file-storage"
    fi

    if [[ "$os" == MINGW64* ]]; then
        ssh_loc=$(which ssh)
        if [[ "$ssh_loc" == "/usr/bin/ssh" ]]; then
            echo "Your ssh command is not pointing to the Windows version of OpenSSH, please run the git-win-setup.sh script"
            exit 1
        fi
    fi

    # verify public key availability
    ssh -V
    if [[ "$?" != "0" ]]; then
        echo -e "OpenSSH must be installed on this system before using Git"
        exit 1
    fi

    ls ~/.ssh/id_rsa.pub
    if [[ "$?" != "0" ]]; then
        echo -e "There is no public key file in ~/.ssh/id_rsa.pub, if you aren't using a properly configured ssh-agent"
        echo -e "then you will have to create a private/public key and get it uploaded to both Git and Artifactory."
        exit 1;
    fi
}

# Execute a command, or just echo if in test mode
#
# param $1 - command string
exec_t() {
    if [[ "$test_run" -eq "1" ]]; then
        echo "exec_t: $1"
    else
        eval "${1}"
    fi
}

# Read the inclusion/exclusion patterns from a file. Thes patterns
# Should follow the form of those in the .gitignore
#
# param $1 - The path to the pattern file
#
# returns a string of the patterns in the file
read_patterns() {
    pat_str=""

    while IFS= read -r pat; do
        pat_str="${pat_str}'${pat}' "
    done < "$1"

    echo $pat_str
}

while getopts "hcxtr:e:p:d:b:" arg; do
    case $arg in
        h)
            usage
            ;;
        c)
            check-env
            exit 0;
            ;;
        d)
            depth=${OPTARG}
            depth_arg="--depth=$depth"
            ;;
        e)
            dev_env=${OPTARG}
            if [[ "$dev_env" == "stak" ]]; then
                dir_patterns=$stak_pat
            elif [[ "$dev_env" == "win" ]]; then
                dir_patterns=$win_pat
            elif [[ "$dev_env" == "il-d" ]]; then
                dir_patterns=$il_dev_pat
            elif [[ "$dev_env" == "il-b" ]]; then
                dir_patterns=$il_build_pat
            elif [[ "$dev_env" == "userdocauto" ]]; then
                dir_patterns=$userdocauto_pat
            elif [[ "$dev_env" == "techpubs" ]]; then
                dir_patterns=$tech_pubs_pat
            elif [[ "$dev_env" == "all" ]]; then
                dir_patterns=""
                depth_arg=""
            fi
            ;;
        r)
            repo=${OPTARG}
            ;;
        p)
            pat_file=${OPTARG}
            echo -e "got pat file: $pat_file"
            dir_patterns=$(read_patterns $pat_file)
            ;;
        b)
            branch=${OPTARG}
            ;;
        t)
            test_run=1
            ;;
        x)
            set -x
            ;;
        *)
            usage
            ;;
    esac
done
shift $((OPTIND-1))

# if [ -z "${1}" ]; then
#     usage
# fi

echo -e "***** last arg: $1"

if [[ "$1" != "" ]]; then
    clone_dir="$1"
fi

if [[ "$branch" != "" ]]; then
    branch_name=$branch
    branch="--branch $branch"
else
    branch="--no-single-branch"
fi

# 2. Fast clone the testcenter repo, no blobs depth 1 or 2
# if [[ "$dir_patterns" == "" ]]; then
#     exec_t "git clone $repo $clone_dir"
#     exit $?
# else
     exec_t "git clone --filter=blob:none --no-checkout $branch $depth_arg $repo $clone_dir"
# fi

if [[ "$clone_dir" == "" ]]; then
    clone_dir=$(echo $repo | awk -F'/' '{print $NF}' | awk -F'.' '{print $1}')
fi

echo -e "clone_dir: $clone_dir"
exec_t "pushd $clone_dir"

# 3. Set sparse-checkout paths
exec_t "git sparse-checkout init --cone"

# 4. Checkout main
if [[ "$dir_patterns" == "" ]]; then
    echo -e "Checking out all, disabling sparse-checkout"
    exec_t "git sparse-checkout disable"
else
    echo -e "sparse checkout patterns: $dir_patterns"
    exec_t "git sparse-checkout set --no-cone $dir_patterns"
fi

exec_t "git checkout $branch_name"

exec_t "popd"
