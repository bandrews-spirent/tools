import os
import subprocess

replace = {"boost_regex-vc141-mt-gd-1_64.lib": "boost_regex.lib",
           "boost_filesystem-vc141-mt-gd-1_64.lib": "boost_filesystem.lib",
           "boost_system-vc141-mt-gd-1_64.lib": "boost_system.lib",
           "boost_date_time-vc141-mt-gd-1_64.lib": "boost_date_time.lib",
           "boost_regex-vc141-mt-1_64.lib": "boost_regex.lib",
           "boost_filesystem-vc141-mt-1_64.lib": "boost_filesystem.lib",
           "boost_system-vc141-mt-1_64.lib": "boost_system.lib",
           "boost_date_time-vc141-mt-1_64.lib": "boost_date_time.lib",
           "boost_serialization-vc141-mt-1_64.lib": "boost_serialization.lib",
           "boost_serialization-vc141-mt-gd-1_64.lib": "boost_serialization.lib",
           "boost_thread-vc141-mt-1_64.lib": "boost_thread.lib",
           "boost_thread-vc141-mt-gd-1_64.lib": "boost_thread.lib",
           "boost_1_64_0": "boost_1_85_0"}
#replace = {"ACE_wrappers_5.5.6": "ACE_wrappers_6.1.6"}

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines

def make_replacement(path):
    out = exec_cmd("p4 edit " + path)
    print(out)
    with open(path, "r") as f:
        data = f.read()
        for k, v in replace.items():
            data = data.replace(k, v)
    with open(path, "w") as f:
        f.write(data)

for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == "SConscript.bll"]
    for file in files:
        root = root.replace('mldSnooping', 'mldsnooping')
        path = os.path.join(root, file)
        make_replacement(path)
