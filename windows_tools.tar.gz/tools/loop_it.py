import os
import sys
import time

if len(sys.argv) != 3:
  print("Usage: %s <command> <loop_count>" % sys.argv[0])
  sys.exit(1)

cmd = sys.argv[1]
count = int(sys.argv[2])

for i in range(0, count):
    ret = os.system(cmd)
    if ret != 0:
        sys.exit(ret);
    print("iteration %d complete" % (i+1))