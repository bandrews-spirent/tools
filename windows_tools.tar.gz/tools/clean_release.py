import os
import shutil

to_remove = []
for root, dirs, files, in os.walk("."):
    for dir in dirs:
        if dir == 'Release':
            path = os.path.join(root, dir)
            if path.endswith('bll\\Release') or path.endswith('obj\\x64\\Release') or path.endswith('obj\\x86\\Release'):
                to_remove.append(path)

for path in to_remove:
    print 'Removing ', path, '...'
    shutil.rmtree(path)
