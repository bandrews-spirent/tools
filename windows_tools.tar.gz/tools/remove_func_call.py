import os
import subprocess

def exec_cmd(cmd):
    proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE)
    lines = []
    for line in proc.stdout.readlines():
      lines.append(line.rstrip())
    return lines


def remove_func(path):
    out = exec_cmd('p4 edit "%s"' % path)
    print(out)
    outlines = []
    with open(path, 'r') as f:
        lines = f.readlines()
        for line in lines:
            if line.find('// From Auto Gen') == -1 and \
                line.find('RegisterCommandStatusMetaInfo') == -1 and \
                line.find('// From Autogen') == -1 and \
                line.find('/* from autogen */') == -1:
                outlines.append(line)

    with open(path, 'w') as f:
        for line in outlines:
            f.write(line)


for root, dirs, files, in os.walk("."):
    files = [f for f in files if f == 'init.cpp']
    for file in files:
        path = os.path.join(root, file)
        if path.find('cts') != -1 and path.find('mldSnooping') == -1:
            print(path)
            remove_func(path)
