import requests

BASE_URI = 'http://localhost:9700'

# Initial connection uses no cursor
r = requests.get(BASE_URI + '/command/statuses')
print(r.status_code)
j = r.json()
print(j)

cursor = j['cursor']
# All subsequent requests use the cursor for long polling
while True:
    r = requests.get(BASE_URI + '/command/statuses/?cursor=' + cursor)
    print(r.status_code)
    print(r.json())